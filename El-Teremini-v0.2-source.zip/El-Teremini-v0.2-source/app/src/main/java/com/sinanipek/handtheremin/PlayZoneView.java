package com.sinanipek.handtheremin;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public final class PlayZoneView extends View {
    private final Paint line = new Paint(1), fillPitch = new Paint(1),
            fillVolume = new Paint(1), text = new Paint(1);
    private float pitchAmount, volumeAmount;
    private boolean pitchFound, volumeFound;

    public PlayZoneView(Context context) {
        super(context);
        setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(4);
        fillPitch.setColor(0x997C5CFF); fillVolume.setColor(0x9938D996);
        text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER);
    }

    public void update(float pitch, boolean hasPitch, float volume, boolean hasVolume) {
        pitchAmount = pitch; pitchFound = hasPitch;
        volumeAmount = volume; volumeFound = hasVolume;
        postInvalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float top = getHeight() * 0.19f, bottom = getHeight() * 0.82f;
        RectF pitch = new RectF(getWidth() * 0.04f, top, getWidth() * 0.46f, bottom);
        RectF volume = new RectF(getWidth() * 0.54f, top, getWidth() * 0.96f, bottom);
        drawZone(canvas, pitch, pitchAmount, pitchFound, fillPitch,
                "NOTA ELİ", "UZAK • KALIN", "YAKIN • İNCE");
        drawZone(canvas, volume, volumeAmount, volumeFound, fillVolume,
                "SES ELİ", "UZAK • KISIK", "YAKIN • YÜKSEK");
        line.setColor(0x66FFFFFF); line.setStrokeWidth(2);
        canvas.drawLine(getWidth() / 2f, top, getWidth() / 2f, bottom, line);
    }

    private void drawZone(Canvas c, RectF zone, float amount, boolean found, Paint fill,
                          String title, String low, String high) {
        line.setStrokeWidth(4); line.setColor(found ? 0xFFFFFFFF : 0x88FFFFFF);
        c.drawRoundRect(zone, 24, 24, line);
        if (found) {
            c.drawRoundRect(new RectF(zone.left,
                    zone.bottom - zone.height() * amount, zone.right, zone.bottom), 24, 24, fill);
        }
        text.setTextSize(30); text.setColor(found ? Color.WHITE : 0xFFB6B6C2);
        c.drawText(title, zone.centerX(), zone.top + 42, text);
        text.setTextSize(20);
        c.drawText(found ? "EL ALGILANDI" : "ELİNİ BU BÖLGEYE GETİR",
                zone.centerX(), zone.centerY(), text);
        text.setTextSize(17);
        c.drawText(high, zone.centerX(), zone.top + 72, text);
        c.drawText(low, zone.centerX(), zone.bottom - 18, text);
    }
}
