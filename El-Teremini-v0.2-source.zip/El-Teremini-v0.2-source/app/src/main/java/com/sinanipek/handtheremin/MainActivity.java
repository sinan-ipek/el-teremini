package com.sinanipek.handtheremin;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity {
    private static final int PREVIEW_ID = 12345;
    private static final String[] KEYS = {"Do", "Do♯", "Re", "Mi♭", "Mi", "Fa", "Fa♯", "Sol", "La♭", "La", "Si♭", "Si"};
    private static final String[] SCALES = {"Majör", "Doğal minör", "Majör pentatonik", "Minör pentatonik"};
    private static final int[][] INTERVALS = {{0,2,4,5,7,9,11}, {0,2,3,5,7,8,10}, {0,2,4,7,9}, {0,3,5,7,10}};

    private final SynthEngine synth = new SynthEngine();
    private ExecutorService cameraExecutor;
    private Spinner keySpinner, scaleSpinner;
    private TextView noteView, volumeView, statusView;
    private PlayZoneView overlay;
    private int lastIndex = -1;

    private final ActivityResultLauncher<String> permission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), ok -> {
                if (ok) startCamera(); else statusView.setText("Kamera izni gerekli");
            });

    @Override protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(Color.rgb(9,10,16));
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildUi();
        synth.start();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) startCamera();
        else permission.launch(Manifest.permission.CAMERA);
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xFF090A10);
        PreviewView preview = new PreviewView(this); preview.setId(PREVIEW_ID);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER); preview.setAlpha(0.24f);
        root.addView(preview, new FrameLayout.LayoutParams(-1,-1));
        overlay = new PlayZoneView(this); root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(24,8,24,8); top.setBackgroundColor(0xE6090A10);
        TextView title = label("EL TEREMİNİ", 18); title.setTextColor(0xFFB7A8FF);
        top.addView(title, new LinearLayout.LayoutParams(0,-1,1));
        keySpinner = spinner(KEYS); keySpinner.setSelection(9);
        scaleSpinner = spinner(SCALES);
        top.addView(keySpinner, new LinearLayout.LayoutParams(190,56));
        top.addView(scaleSpinner, new LinearLayout.LayoutParams(260,56));
        root.addView(top, new FrameLayout.LayoutParams(-1,72,Gravity.TOP));

        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(20,6,20,6); bottom.setBackgroundColor(0xE6090A10);
        noteView = label("Nota: —",28); noteView.setGravity(Gravity.CENTER);
        volumeView = label("Ses: —",28); volumeView.setGravity(Gravity.CENTER);
        statusView = label("İki elinizi bölgelerin üzerinde tutun",15);
        statusView.setTextColor(0xFFCBC9D4); statusView.setGravity(Gravity.CENTER);
        bottom.addView(noteView,new LinearLayout.LayoutParams(0,-1,1));
        bottom.addView(statusView,new LinearLayout.LayoutParams(0,-1,1.5f));
        bottom.addView(volumeView,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(bottom,new FrameLayout.LayoutParams(-1,72,Gravity.BOTTOM));
        setContentView(root);
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values));
        return spinner;
    }

    private TextView label(String value, int sp) {
        TextView text = new TextView(this); text.setText(value); text.setTextSize(sp);
        text.setTextColor(Color.WHITE); return text;
    }

    private void startCamera() {
        PreviewView view = findViewById(PREVIEW_ID);
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> { try {
            ProcessCameraProvider provider = future.get();
            Preview preview = new Preview.Builder().build();
            preview.setSurfaceProvider(view.getSurfaceProvider());
            ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setTargetRotation(view.getDisplay().getRotation())
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
            analysis.setAnalyzer(cameraExecutor, new HandAnalyzer((pitch, pitchFound, volume, volumeFound) ->
                    runOnUiThread(() -> onHands(pitch, pitchFound, volume, volumeFound))));
            provider.unbindAll();
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis);
        } catch (Exception error) {
            statusView.setText("Kamera başlatılamadı: " + error.getMessage());
        }}, ContextCompat.getMainExecutor(this));
    }

    private void onHands(float pitchAmount, boolean pitchFound,
                         float volumeAmount, boolean volumeFound) {
        overlay.update(pitchAmount, pitchFound, volumeAmount, volumeFound);
        double volume = volumeFound ? volumeAmount : 0.0;
        volumeView.setText(volumeFound ? String.format(Locale.getDefault(), "Ses: %%%d", Math.round(volume * 100)) : "Ses: —");

        if (!pitchFound) {
            synth.setState(220, 0, false); noteView.setText("Nota: —");
            statusView.setText("Sol bölgeye nota elinizi getirin"); lastIndex = -1; return;
        }

        int[] scale = INTERVALS[scaleSpinner.getSelectedItemPosition()];
        int count = scale.length * 2 + 1;
        int index = Math.min(count - 1, (int)(pitchAmount * count));
        if (lastIndex >= 0 && Math.abs(index - lastIndex) == 1) {
            float boundary = (float)Math.max(index, lastIndex) / count;
            if (Math.abs(pitchAmount - boundary) < 0.018f) index = lastIndex;
        }
        lastIndex = index;
        int degree = index % scale.length, octave = index / scale.length;
        int root = keySpinner.getSelectedItemPosition();
        int midi = 48 + root + scale[degree] + 12 * octave;
        double hz = 440.0 * Math.pow(2.0, (midi - 69) / 12.0);
        String name = KEYS[(root + scale[degree]) % 12] + (3 + octave);
        boolean audible = volumeFound && volume > 0.025;
        synth.setState(hz, volume, audible);
        noteView.setText("Nota: " + name);
        statusView.setText(volumeFound ? "İki el algılandı" : "Sağ bölgeye ses elinizi getirin");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
        synth.stop();
    }
}
