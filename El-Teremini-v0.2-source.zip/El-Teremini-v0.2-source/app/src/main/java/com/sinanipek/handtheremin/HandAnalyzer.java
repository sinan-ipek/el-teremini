package com.sinanipek.handtheremin;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import java.nio.ByteBuffer;

public final class HandAnalyzer implements ImageAnalysis.Analyzer {
    public interface Listener {
        void onMeasurement(float pitchAmount, boolean pitchFound,
                           float volumeAmount, boolean volumeFound);
    }

    private final Listener listener;
    private float smoothPitch;
    private float smoothVolume;

    public HandAnalyzer(Listener listener) { this.listener = listener; }

    @Override public void analyze(@NonNull ImageProxy image) {
        ImageProxy.PlaneProxy yPlane = image.getPlanes()[0];
        ImageProxy.PlaneProxy uPlane = image.getPlanes()[1];
        ImageProxy.PlaneProxy vPlane = image.getPlanes()[2];
        ByteBuffer yb = yPlane.getBuffer(), ub = uPlane.getBuffer(), vb = vPlane.getBuffer();
        int w = image.getWidth(), h = image.getHeight();
        int yStride = yPlane.getRowStride(), uvStride = uPlane.getRowStride();
        int uvPixel = uPlane.getPixelStride();
        int rotation = image.getImageInfo().getRotationDegrees();

        Measurement pitch = measureDisplayZone(yb, ub, vb, w, h, yStride, uvStride,
                uvPixel, rotation, 0.04f, 0.46f, 0.15f, 0.90f);
        Measurement volume = measureDisplayZone(yb, ub, vb, w, h, yStride, uvStride,
                uvPixel, rotation, 0.54f, 0.96f, 0.15f, 0.90f);

        smoothPitch += (pitch.amount - smoothPitch) * (pitch.found ? 0.25f : 0.10f);
        smoothVolume += (volume.amount - smoothVolume) * (volume.found ? 0.25f : 0.10f);
        listener.onMeasurement(smoothPitch, pitch.found, smoothVolume, volume.found);
        image.close();
    }

    private static Measurement measureDisplayZone(ByteBuffer yb, ByteBuffer ub, ByteBuffer vb,
            int w, int h, int yStride, int uvStride, int uvPixel, int rotation,
            float left, float right, float top, float bottom) {
        int skin = 0, samples = 0;
        for (float ny = top; ny < bottom; ny += 0.018f) {
            for (float nx = left; nx < right; nx += 0.018f) {
                int[] point = displayToBuffer(nx, ny, w, h, rotation);
                int x = point[0], y = point[1];
                int yy = yb.get(y * yStride + x) & 255;
                int uvIndex = (y / 2) * uvStride + (x / 2) * uvPixel;
                int u = ub.get(uvIndex) & 255, v = vb.get(uvIndex) & 255;
                if (yy > 32 && v > 130 && v < 184 && u > 70 && u < 140) skin++;
                samples++;
            }
        }
        float ratio = samples == 0 ? 0f : (float) skin / samples;
        boolean found = ratio > 0.022f;
        return new Measurement(clamp((ratio - 0.022f) / 0.43f, 0f, 1f), found);
    }

    private static int[] displayToBuffer(float nx, float ny, int w, int h, int rotation) {
        // Ön kamera önizlemesi yatay aynalıdır; analiz koordinatını aynı görünüme uyarlar.
        nx = 1f - nx;
        float bx, by;
        if (rotation == 90) { bx = ny; by = 1f - nx; }
        else if (rotation == 180) { bx = 1f - nx; by = 1f - ny; }
        else if (rotation == 270) { bx = 1f - ny; by = nx; }
        else { bx = nx; by = ny; }
        int x = Math.max(0, Math.min(w - 1, (int)(bx * (w - 1))));
        int y = Math.max(0, Math.min(h - 1, (int)(by * (h - 1))));
        return new int[]{x, y};
    }

    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }

    private static final class Measurement {
        final float amount; final boolean found;
        Measurement(float amount, boolean found) { this.amount = amount; this.found = found; }
    }
}
