# El Teremini v0.2

Telefonu masaya yatay ve ekranı yukarı bakacak biçimde koyun.

- Sol el: kameraya yaklaştıkça seçilen gamda daha ince notalar çalar.
- Sağ el: kameraya yaklaştıkça ses yükselir, uzaklaştıkça kısılır.
- Nota eli kaybolursa ses kesilir.
- Kamera görüntüsü yalnızca cihazda işlenir; kaydedilmez ve gönderilmez.

Android 8.0 ve üzeri için hazırlanmıştır.
