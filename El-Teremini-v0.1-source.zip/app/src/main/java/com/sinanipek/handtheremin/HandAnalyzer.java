package com.sinanipek.handtheremin;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import java.nio.ByteBuffer;

public final class HandAnalyzer implements ImageAnalysis.Analyzer {
    public interface Listener { void onMeasurement(float amount, boolean found); }
    private final Listener listener;
    private float smooth;

    public HandAnalyzer(Listener listener) { this.listener = listener; }

    @Override public void analyze(@NonNull ImageProxy image) {
        ImageProxy.PlaneProxy yPlane = image.getPlanes()[0];
        ImageProxy.PlaneProxy uPlane = image.getPlanes()[1];
        ImageProxy.PlaneProxy vPlane = image.getPlanes()[2];
        ByteBuffer yb = yPlane.getBuffer(), ub = uPlane.getBuffer(), vb = vPlane.getBuffer();
        int w = image.getWidth(), h = image.getHeight();
        int yStride = yPlane.getRowStride(), uvStride = uPlane.getRowStride();
        int uvPixel = uPlane.getPixelStride();

        // Ön kameranın sağ kenarı: yüzün dışında kalan el çalma bölgesi.
        int x0 = (int)(w * 0.05), x1 = (int)(w * 0.43);
        int y0 = (int)(h * 0.12), y1 = (int)(h * 0.88);
        int skin = 0, samples = 0;
        for (int y = y0; y < y1; y += 4) {
            for (int x = x0; x < x1; x += 4) {
                int yy = yb.get(y * yStride + x) & 255;
                int uvIndex = (y / 2) * uvStride + (x / 2) * uvPixel;
                int u = ub.get(uvIndex) & 255, v = vb.get(uvIndex) & 255;
                // Geniş YCbCr ten aralığı; farklı ten renkleri ve iç mekân ışığı için.
                if (yy > 35 && v > 132 && v < 181 && u > 74 && u < 136) skin++;
                samples++;
            }
        }
        float ratio = samples == 0 ? 0 : (float) skin / samples;
        boolean found = ratio > 0.025f;
        float normalized = clamp((ratio - 0.025f) / 0.38f, 0f, 1f);
        smooth += (normalized - smooth) * (found ? 0.24f : 0.10f);
        listener.onMeasurement(smooth, found);
        image.close();
    }

    private static float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }
}
