package com.sinanipek.handtheremin;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public final class PlayZoneView extends View {
    private final Paint line = new Paint(1), fill = new Paint(1), text = new Paint(1);
    private float amount;
    private boolean found;
    public PlayZoneView(Context c) {
        super(c); setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(4); line.setColor(0xCCFFFFFF);
        fill.setColor(0x887C5CFF);
        text.setColor(Color.WHITE); text.setTextSize(34); text.setTextAlign(Paint.Align.CENTER);
    }
    public void update(float value, boolean detected) { amount=value; found=detected; postInvalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float l=getWidth()*0.57f, r=getWidth()*0.95f, t=getHeight()*0.12f, b=getHeight()*0.78f;
        RectF zone = new RectF(l,t,r,b);
        line.setColor(found ? 0xFFFFFFFF : 0x99FFFFFF);
        c.drawRoundRect(zone, 28, 28, line);
        if (found) c.drawRoundRect(new RectF(l, b-(b-t)*amount, r, b), 28, 28, fill);
        c.drawText(found ? "EL ALGILANDI" : "ELİNİ BURAYA GETİR", (l+r)/2, t+48, text);
        text.setTextSize(25);
        c.drawText("UZAK • KALIN", (l+r)/2, b-24, text);
        c.drawText("YAKIN • İNCE", (l+r)/2, t+86, text);
        text.setTextSize(34);
    }
}
