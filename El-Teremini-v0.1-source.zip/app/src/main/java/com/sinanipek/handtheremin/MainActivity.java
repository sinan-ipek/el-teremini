package com.sinanipek.handtheremin;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends AppCompatActivity {
    private static final String[] KEYS = {"Do", "Do♯", "Re", "Mi♭", "Mi", "Fa", "Fa♯", "Sol", "La♭", "La", "Si♭", "Si"};
    private static final String[] SCALES = {"Majör", "Doğal minör", "Majör pentatonik", "Minör pentatonik"};
    private static final int[][] INTERVALS = {{0,2,4,5,7,9,11}, {0,2,3,5,7,8,10}, {0,2,4,7,9}, {0,3,5,7,10}};
    private final SynthEngine synth = new SynthEngine();
    private ExecutorService cameraExecutor;
    private Spinner keySpinner, scaleSpinner;
    private TextView noteView, statusView;
    private PlayZoneView overlay;
    private int lastIndex = -1;

    private final ActivityResultLauncher<String> permission = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(), ok -> { if (ok) startCamera(); else statusView.setText("Kamera izni gerekli"); });

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,10,16));
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildUi();
        synth.start();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera();
        else permission.launch(Manifest.permission.CAMERA);
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(0xFF090A10);
        PreviewView preview = new PreviewView(this); preview.setId(12345); preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview, new FrameLayout.LayoutParams(-1,-1));
        overlay = new PlayZoneView(this); root.addView(overlay, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL); top.setPadding(28,22,28,20); top.setBackgroundColor(0xCC090A10);
        TextView title = label("EL TEREMİNİ", 18); title.setTextColor(0xFFB7A8FF); top.addView(title);
        LinearLayout choices = new LinearLayout(this); choices.setOrientation(LinearLayout.HORIZONTAL);
        keySpinner = spinner(KEYS); keySpinner.setSelection(9); scaleSpinner = spinner(SCALES);
        choices.addView(keySpinner, new LinearLayout.LayoutParams(0,64,1)); choices.addView(scaleSpinner, new LinearLayout.LayoutParams(0,64,1)); top.addView(choices);
        root.addView(top, new FrameLayout.LayoutParams(-1,150, Gravity.TOP));

        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER); bottom.setOrientation(LinearLayout.VERTICAL); bottom.setPadding(20,12,20,20); bottom.setBackgroundColor(0xDD090A10);
        noteView=label("—",54); noteView.setGravity(Gravity.CENTER); bottom.addView(noteView,new LinearLayout.LayoutParams(-1,70));
        statusView=label("Elinizi çerçeveye getirin",16); statusView.setGravity(Gravity.CENTER); statusView.setTextColor(0xFFCBC9D4); bottom.addView(statusView);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,130,Gravity.BOTTOM); root.addView(bottom,bp);
        setContentView(root);
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this); ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values); s.setAdapter(a); return s;
    }
    private TextView label(String value,int sp) { TextView t=new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(Color.WHITE); return t; }

    private void startCamera() {
        PreviewView view=findViewById(12345);
        ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);
        f.addListener(() -> { try {
            ProcessCameraProvider p=f.get(); Preview preview=new Preview.Builder().build(); preview.setSurfaceProvider(view.getSurfaceProvider());
            ImageAnalysis analysis=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
            analysis.setAnalyzer(cameraExecutor,new HandAnalyzer((amount,found)->runOnUiThread(()->onHand(amount,found))));
            p.unbindAll(); p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview,analysis);
        } catch(Exception e) { statusView.setText("Kamera başlatılamadı: "+e.getMessage()); } },ContextCompat.getMainExecutor(this));
    }

    private void onHand(float amount, boolean found) {
        overlay.update(amount,found);
        if (!found) { synth.setNote(220,false); noteView.setText("—"); statusView.setText("Elinizi çerçeveye getirin"); lastIndex=-1; return; }
        int[] scale=INTERVALS[scaleSpinner.getSelectedItemPosition()];
        int count=scale.length*2+1;
        int index=Math.min(count-1,(int)(amount*count));
        // Sınır yakınlarında tek karelik nota zıplamasını azaltır.
        if (lastIndex>=0 && Math.abs(index-lastIndex)==1) {
            float boundary=(float)Math.max(index,lastIndex)/count;
            if (Math.abs(amount-boundary)<0.018f) index=lastIndex;
        }
        lastIndex=index;
        int degree=index%scale.length, octave=index/scale.length;
        int midi=48+keySpinner.getSelectedItemPosition()+scale[degree]+12*octave;
        double hz=440.0*Math.pow(2.0,(midi-69)/12.0);
        String name=KEYS[(keySpinner.getSelectedItemPosition()+scale[degree])%12]+(3+octave);
        synth.setNote(hz,true); noteView.setText(name); statusView.setText(String.format("%s  •  %.1f Hz",scaleSpinner.getSelectedItem(),hz));
    }

    @Override protected void onDestroy() { super.onDestroy(); if(cameraExecutor!=null) cameraExecutor.shutdown(); synth.stop(); }
}
