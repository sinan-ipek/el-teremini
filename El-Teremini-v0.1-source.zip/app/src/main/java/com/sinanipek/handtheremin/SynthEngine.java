package com.sinanipek.handtheremin;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

public final class SynthEngine {
    private static final int SAMPLE_RATE = 44100;
    private volatile boolean running;
    private volatile boolean audible;
    private volatile double targetHz = 220.0;
    private Thread thread;
    private AudioTrack track;

    public void start() {
        if (running) return;
        int min = AudioTrack.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM).build();
        running = true;
        track.play();
        thread = new Thread(this::audioLoop, "ThereminSynth");
        thread.start();
    }

    public void setNote(double hz, boolean on) { targetHz = hz; audible = on; }

    private void audioLoop() {
        short[] pcm = new short[512];
        double phase = 0, hz = targetHz, gain = 0;
        while (running) {
            for (int i = 0; i < pcm.length; i++) {
                hz += (targetHz - hz) * 0.0025; // kısa portamento
                double wantedGain = audible ? 0.22 : 0.0;
                gain += (wantedGain - gain) * 0.004; // tıklamasız aç/kapa
                phase += 2.0 * Math.PI * hz / SAMPLE_RATE;
                if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI;
                double fundamental = Math.sin(phase);
                double harmonic = 0.18 * Math.sin(2.0 * phase);
                pcm[i] = (short) (32767.0 * gain * (fundamental + harmonic) / 1.18);
            }
            track.write(pcm, 0, pcm.length, AudioTrack.WRITE_BLOCKING);
        }
    }

    public void stop() {
        running = false;
        audible = false;
        if (thread != null) try { thread.join(300); } catch (InterruptedException ignored) {}
        if (track != null) { track.pause(); track.flush(); track.release(); track = null; }
    }
}
